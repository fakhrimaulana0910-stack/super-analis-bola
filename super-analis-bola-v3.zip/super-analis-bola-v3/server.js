import http from 'node:http';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PUBLIC_DIR = path.join(__dirname, 'public');
const PORT = Number(process.env.PORT || 3000);
const MAX_BODY_BYTES = 1_000_000;
const RATE_WINDOW_MS = 60_000;
const RATE_LIMIT = Number(process.env.RATE_LIMIT || 30);
const rateBuckets = new Map();
const API_KEY = process.env.API_FOOTBALL_KEY || '';
const CACHE_TTL_MS = Number(process.env.CACHE_TTL_MS || 15 * 60 * 1000);
const API_BASE = 'https://v3.football.api-sports.io';
const WEATHER_BASE = 'https://api.open-meteo.com/v1/forecast';
const GEOCODE_BASE = 'https://geocoding-api.open-meteo.com/v1/search';

const cache = new Map();

function nowMs() { return Date.now(); }
function clientKey(req) { return req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.socket.remoteAddress || 'local'; }
function rateAllowed(req) {
  const key = clientKey(req); const now = nowMs();
  const row = rateBuckets.get(key) || { start: now, count: 0 };
  if (now - row.start >= RATE_WINDOW_MS) { row.start = now; row.count = 0; }
  row.count += 1; rateBuckets.set(key, row);
  return row.count <= RATE_LIMIT;
}
function json(res, status, body) {
  const out = JSON.stringify(body);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    'Access-Control-Allow-Origin': '*',
  });
  res.end(out);
}
function sendFile(res, filePath) {
  const ext = path.extname(filePath);
  const types = {
    '.html': 'text/html; charset=utf-8',
    '.js': 'text/javascript; charset=utf-8',
    '.css': 'text/css; charset=utf-8',
    '.json': 'application/json; charset=utf-8',
    '.webmanifest': 'application/manifest+json; charset=utf-8',
    '.png': 'image/png',
    '.svg': 'image/svg+xml',
    '.ico': 'image/x-icon'
  };
  return fs.readFile(filePath).then(buf => {
    res.writeHead(200, { 'Content-Type': types[ext] || 'application/octet-stream' });
    res.end(buf);
  }).catch(() => json(res, 404, { error: 'file tidak ditemukan' }));
}

async function cached(key, fn, ttl = CACHE_TTL_MS) {
  const hit = cache.get(key);
  if (hit && nowMs() - hit.ts < ttl) return hit.value;
  const value = await fn();
  cache.set(key, { ts: nowMs(), value });
  return value;
}

async function apiFootball(endpoint, params = {}) {
  if (!API_KEY) {
    throw new Error('API_FOOTBALL_KEY belum diisi.');
  }
  const url = new URL(API_BASE + endpoint);
  for (const [k, v] of Object.entries(params)) {
    if (v !== undefined && v !== null && v !== '') url.searchParams.set(k, String(v));
  }
  const res = await fetch(url, {
    headers: { 'x-apisports-key': API_KEY },
    signal: AbortSignal.timeout(20000),
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(`API-Football ${res.status}: ${data?.message || res.statusText}`);
  if (Array.isArray(data.errors) && data.errors.length) {
    throw new Error(`API-Football: ${JSON.stringify(data.errors)}`);
  }
  return data;
}

async function weatherGet(url) {
  const res = await fetch(url, { signal: AbortSignal.timeout(15000) });
  if (!res.ok) throw new Error(`Open-Meteo ${res.status}`);
  return res.json();
}

function norm(s = '') {
  return s.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]+/g, ' ').trim();
}
function clamp(n, a, b) { return Math.max(a, Math.min(b, n)); }
function mean(arr) { const a = arr.filter(Number.isFinite); return a.length ? a.reduce((x,y)=>x+y,0)/a.length : null; }
function weightedMean(values) {
  const good = values.filter(v => Number.isFinite(v.value));
  if (!good.length) return null;
  let sw = 0, sx = 0;
  for (const v of good) { sw += v.weight; sx += v.value * v.weight; }
  return sx / sw;
}
function daysBetween(a, b) { return Math.abs(new Date(a).getTime() - new Date(b).getTime()) / 86400000; }
function poissonPmf(k, lambda) {
  const l = Math.max(0.01, lambda);
  let p = Math.exp(-l);
  for (let i = 1; i <= k; i++) p *= l / i;
  return p;
}
function dcTau(h, a, lh, la, rho = -0.13) {
  if (h === 0 && a === 0) return 1 - lh * la * rho;
  if (h === 0 && a === 1) return 1 + lh * rho;
  if (h === 1 && a === 0) return 1 + la * rho;
  if (h === 1 && a === 1) return 1 - rho;
  return 1;
}
function distribution(lh, la, rho = -0.13, maxGoals = 8) {
  const m = [];
  let total = 0;
  for (let h=0; h<=maxGoals; h++) {
    for (let a=0; a<=maxGoals; a++) {
      const p = poissonPmf(h, lh) * poissonPmf(a, la) * dcTau(h, a, lh, la, rho);
      const pp = Math.max(0, p);
      m.push({ h, a, p: pp }); total += pp;
    }
  }
  return m.map(x => ({ ...x, p: x.p / total }));
}
function sampleFromDistribution(dist, rng) {
  let r = rng();
  for (const x of dist) {
    r -= x.p;
    if (r <= 0) return x;
  }
  return dist[dist.length - 1];
}
function mulberry32(seed) {
  return function() {
    let t = seed += 0x6D2B79F5;
    t = Math.imul(t ^ t >>> 15, t | 1);
    t ^= t + Math.imul(t ^ t >>> 7, t | 61);
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  };
}
function pct(n) { return Number.isFinite(n) ? +(n * 100).toFixed(1) : null; }
function fmtPct(n) { return n == null ? 'data tidak tersedia' : `${n.toFixed(1)}%`; }
function isoDay(date) { return new Date(date).toISOString().slice(0, 10); }
function statusPlayed(f) { return ['FT','AET','PEN'].includes(f?.fixture?.status?.short); }
function scoreOf(f) {
  return { home: Number(f?.goals?.home), away: Number(f?.goals?.away) };
}
function resultForTeam(f, teamId) {
  const s = scoreOf(f); if (!Number.isFinite(s.home) || !Number.isFinite(s.away)) return null;
  const isHome = Number(f.teams?.home?.id) === Number(teamId);
  const gf = isHome ? s.home : s.away;
  const ga = isHome ? s.away : s.home;
  return { gf, ga, result: gf>ga?'W':gf<ga?'L':'D', isHome };
}
function summarizeFixtures(fixtures, teamId) {
  const played = (fixtures || []).filter(statusPlayed);
  const rows = played.map(f => ({
    date: f.fixture.date,
    league: f.league?.name || null,
    opponent: Number(f.teams?.home?.id) === Number(teamId) ? f.teams?.away?.name : f.teams?.home?.name,
    homeAway: Number(f.teams?.home?.id) === Number(teamId) ? 'H' : 'A',
    ...resultForTeam(f, teamId)
  })).filter(x => x.result);
  const form = rows.map(x=>x.result).join('');
  const weightedGF = weightedMean(rows.slice(-10).map((r,i)=>({ value:r.gf, weight:i+1 })));
  const weightedGA = weightedMean(rows.slice(-10).map((r,i)=>({ value:r.ga, weight:i+1 })));
  const home = rows.filter(r=>r.isHome);
  const away = rows.filter(r=>!r.isHome);
  return {
    rows,
    form,
    weightedGF,
    weightedGA,
    avgGF: mean(rows.map(r=>r.gf)),
    avgGA: mean(rows.map(r=>r.ga)),
    homeGF: mean(home.map(r=>r.gf)), homeGA: mean(home.map(r=>r.ga)), homeN: home.length,
    awayGF: mean(away.map(r=>r.gf)), awayGA: mean(away.map(r=>r.ga)), awayN: away.length,
    recentN: rows.length,
    lastDate: rows.length ? rows[rows.length-1].date : null
  };
}

function calcElo(fixtures, teamId, standings = [], homeAdv=55, K=24) {
  // Local Elo: opponents start at 1500 because a complete league-wide fixture graph
  // is not available in this request. This is explicitly returned as a proxy, not a
  // fabricated official Elo rating.
  let elo = 1500;
  const oppRatings = new Map();
  const rows = (fixtures||[]).filter(statusPlayed).slice(-10).sort((a,b)=>new Date(a.fixture.date)-new Date(b.fixture.date));
  for (const f of rows) {
    const r = resultForTeam(f, teamId); if (!r) continue;
    const oppId = Number(r.isHome ? f.teams?.away?.id : f.teams?.home?.id);
    const oppStand = standings.find(x=>Number(x.team?.id)===oppId);
    const opp = oppRatings.get(oppId) ?? (oppStand?.rank ? 1500 + (20 - Math.min(20, oppStand.rank))*8 : 1500);
    const ratingDiff = (r.isHome ? homeAdv : -homeAdv) + elo - opp;
    const expected = 1 / (1 + Math.pow(10, -ratingDiff/400));
    const actual = r.result === 'W' ? 1 : r.result === 'D' ? 0.5 : 0;
    const margin = Math.max(1, Math.abs(r.gf-r.ga));
    const mult = Math.log(margin + 1) + 0.75;
    elo += K * mult * (actual - expected);
    oppRatings.set(oppId, opp + K * mult * (expected - actual));
  }
  return elo;
}

function extractXg(statsResponse, teamId) {
  const arr = statsResponse?.response || [];
  for (const block of arr) {
    if (Number(block?.team?.id) !== Number(teamId)) continue;
    for (const item of block?.statistics || []) {
      const n = norm(item?.type || '');
      if (n.includes('expected goals') || n === 'xg' || n.includes('xg')) {
        const raw = item?.value;
        const val = typeof raw === 'string' ? parseFloat(raw.replace(',', '.')) : Number(raw);
        if (Number.isFinite(val)) return val;
      }
    }
  }
  return null;
}

function parsePctValue(v) {
  if (typeof v === 'number') return v;
  if (typeof v !== 'string') return null;
  const n = parseFloat(v.replace('%','').replace(',','.'));
  return Number.isFinite(n) ? n : null;
}

function flattenOdds(raw) {
  const out = [];
  const books = [];
  for (const item of raw?.response || []) {
    for (const book of item.bookmakers || []) {
      books.push(book.name);
      for (const bet of book.bets || []) {
        for (const v of bet.values || []) {
          const odd = parseFloat(String(v.odd ?? '').replace(',','.'));
          if (!Number.isFinite(odd)) continue;
          out.push({ bookmaker: book.name, betName: bet.name, label: v.value, odd });
        }
      }
    }
  }
  return { rows: out, bookmakers: [...new Set(books)] };
}
function implied(odd) { return odd > 1 ? 1/odd : null; }

function findOddsChoice(oddsRows, predicate) {
  const matches = oddsRows.filter(predicate).filter(x=>x.odd>1);
  if (!matches.length) return null;
  matches.sort((a,b)=>b.odd-a.odd);
  return matches[0];
}
function normalizeMarketRows(oddsRows, homeName, awayName) {
  const H = norm(homeName), A = norm(awayName);
  const is = (s, token) => norm(s).includes(token);
  const rows = {
    home: findOddsChoice(oddsRows, r=>is(r.betName,'match winner') && /^(home|1)$/i.test(String(r.label))),
    draw: findOddsChoice(oddsRows, r=>is(r.betName,'match winner') && /^(draw|x)$/i.test(String(r.label))),
    away: findOddsChoice(oddsRows, r=>is(r.betName,'match winner') && /^(away|2)$/i.test(String(r.label))),
    dc1X: findOddsChoice(oddsRows, r=>is(r.betName,'double chance') && /home\/draw|1\/x/i.test(norm(r.label))),
    dc12: findOddsChoice(oddsRows, r=>is(r.betName,'double chance') && /home\/away|1\/2/i.test(norm(r.label))),
    dcX2: findOddsChoice(oddsRows, r=>is(r.betName,'double chance') && /draw\/away|x\/2/i.test(norm(r.label))),
    over25: findOddsChoice(oddsRows, r=>/goals over\/under|over\/under|total goals/i.test(norm(r.betName)) && /over 2\.5|2\.5 over/i.test(norm(r.label))),
    under25: findOddsChoice(oddsRows, r=>/goals over\/under|over\/under|total goals/i.test(norm(r.betName)) && /under 2\.5|2\.5 under/i.test(norm(r.label))),
    bttsYes: findOddsChoice(oddsRows, r=>/both teams score|btts/i.test(norm(r.betName)) && /yes/i.test(norm(r.label))),
    bttsNo: findOddsChoice(oddsRows, r=>/both teams score|btts/i.test(norm(r.betName)) && /no/i.test(norm(r.label))),
  };
  rows.ahHome = findOddsChoice(oddsRows, r=>/asian handicap/i.test(norm(r.betName)) && /home/i.test(norm(r.label)));
  rows.ahAway = findOddsChoice(oddsRows, r=>/asian handicap/i.test(norm(r.betName)) && /away/i.test(norm(r.label)));
  rows.correct = oddsRows.filter(r=>/correct score/i.test(norm(r.betName))).sort((a,b)=>b.odd-a.odd).slice(0,30);
  return rows;
}

function extractScoreProb(dist, predicate) { return dist.filter(predicate).reduce((s,x)=>s+x.p,0); }
function marketProbabilities(dist) {
  const home = extractScoreProb(dist, x=>x.h>x.a);
  const draw = extractScoreProb(dist, x=>x.h===x.a);
  const away = extractScoreProb(dist, x=>x.h<x.a);
  const dc1X = home + draw, dc12 = home + away, dcX2 = draw + away;
  const over25 = extractScoreProb(dist,x=>x.h+x.a>2);
  const under25 = 1-over25;
  const bttsYes = extractScoreProb(dist,x=>x.h>0 && x.a>0);
  const bttsNo = 1-bttsYes;
  const correct = [...dist].sort((a,b)=>b.p-a.p).slice(0,5);
  return { home, draw, away, dc1X, dc12, dcX2, over25, under25, bttsYes, bttsNo, correct };
}

function asianHandicapProb(dist, side, line) {
  // Returns full/half win, push, half loss, full loss probabilities.
  let w=0, hw=0, p=0, hl=0, l=0;
  for (const x of dist) {
    const margin = side === 'home' ? x.h - x.a : x.a - x.h;
    const adj = margin + line;
    if (Math.abs(adj) < 1e-9) p += x.p;
    else if (adj >= 1) w += x.p;
    else if (adj >= 0.5) hw += x.p;
    else if (adj <= -1) l += x.p;
    else hl += x.p;
  }
  return { w, hw, p, hl, l, effective: w + 0.5*hw };
}
function evFromAsian(o, x) {
  if (!o || !x) return null;
  return x.w*(o-1) + x.hw*((o-1)/2) + x.hl*(-0.5) + x.l*(-1);
}

function seedFromString(s='') {
  let h=2166136261;
  for (let i=0;i<s.length;i++) { h^=s.charCodeAt(i); h=Math.imul(h,16777619); }
  return h>>>0;
}

function getPanelFactors(ctx) {
  const { hs, as, h2h, standings, injuriesHome, injuriesAway, xgHome, xgAway, market, weather, squadHome, squadAway } = ctx;
  const formDelta = ((hs.weightedGF ?? 1) - (as.weightedGA ?? 1)) * 0.035;
  const awayFormDelta = ((as.weightedGF ?? 1) - (hs.weightedGA ?? 1)) * 0.035;
  const h2hRows = (h2h||[]).map(f=>({ ...resultForTeam(f, ctx.homeId), date:f.fixture.date })).filter(x=>x.result).slice(-10);
  const h2hGF = mean(h2hRows.map(x=>x.gf)); const h2hGA = mean(h2hRows.map(x=>x.ga));

  const posH = standings?.find(x=>Number(x.team?.id)===Number(ctx.homeId));
  const posA = standings?.find(x=>Number(x.team?.id)===Number(ctx.awayId));
  const posDiff = (posA?.rank ?? null) != null && (posH?.rank ?? null) != null ? posA.rank - posH.rank : 0;
  const motivation = clamp(posDiff * 0.0025, -0.04, 0.04);

  const injH = injuriesHome?.length ?? 0, injA = injuriesAway?.length ?? 0;
  const fatigueH = ctx.recent14H ?? 0, fatigueA = ctx.recent14A ?? 0;
  const weatherSevere = (weather?.windKmh ?? 0) >= 45 || (weather?.precipMm ?? 0) >= 8;
  const psycheH = /W{3,}/.test(hs.form) ? 0.025 : /L{3,}/.test(hs.form) ? -0.025 : 0;
  const psycheA = /W{3,}/.test(as.form) ? 0.025 : /L{3,}/.test(as.form) ? -0.025 : 0;
  const oddsH = market?.home?.odd ? clamp((implied(market.home.odd) - 0.5) * 0.04, -0.02, 0.02) : 0;
  const oddsA = market?.away?.odd ? clamp((implied(market.away.odd) - 0.5) * 0.04, -0.02, 0.02) : 0;
  const eloAdj = eloLambdaAdjustment(ctx.eloHome, ctx.eloAway);

  return [
    { name:'Form', weight:1.15, h:1+formDelta, a:1+awayFormDelta, note:'Form 5–10 laga terakhir dan tren gol.' },
    { name:'Head-to-head', weight:0.75, h: h2hGF!=null ? 1 + clamp((h2hGF-1.0)*0.035,-0.04,0.04) : 1, a: h2hGA!=null ? 1 + clamp((h2hGA-1.0)*0.025,-0.04,0.04) : 1, note:h2hGF!=null?'H2H terakhir':'data tidak tersedia' },
    { name:'Taktik', weight:0.95, h:1 + clamp(((hs.homeGF??hs.avgGF??1)-(as.awayGA??as.avgGA??1))*0.025,-0.05,0.05), a:1 + clamp(((as.awayGF??as.avgGF??1)-(hs.homeGA??hs.avgGA??1))*0.025,-0.05,0.05), note:'Split performa kandang/tandang sebagai proxy struktur taktis.' },
    { name:'Cedera / skorsing', weight:0.7, h:1 - Math.min(injH,6)*0.012, a:1 - Math.min(injA,6)*0.012, note:(injH||injA)?`Terdata: ${injH} home, ${injA} away`:'data tidak tersedia' },
    { name:'xG & statistik gol', weight:1.20, h:xgHome!=null ? 1 + clamp(((xgHome-(hs.avgGF??xgHome))/2)*0.08,-0.05,0.05) : 1, a:xgAway!=null ? 1 + clamp(((xgAway-(as.avgGF??xgAway))/2)*0.08,-0.05,0.05) : 1, note:xgHome!=null&&xgAway!=null?'xG tersedia':'xG data tidak tersedia' },
    { name:'Odds / pasar', weight:0.45, h:1+oddsH, a:1+oddsA, note:market?.home||market?.away?'odds saat ini tersedia':'data odds tidak tersedia' },
    { name:'Motivasi', weight:0.45, h:1+motivation, a:1-motivation, note:standings?.length?'inferensi dari klasemen / konteks kompetisi':'data tidak tersedia' },
    { name:'Kelelahan / jadwal', weight:0.70, h:1-Math.min(Math.max(0,fatigueH-2),4)*0.015, a:1-Math.min(Math.max(0,fatigueA-2),4)*0.015, note:`14 hari terakhir: ${fatigueH || 0} vs ${fatigueA || 0} laga` },
    { name:'Wasit', weight:0.30, h:1, a:1, note:ctx.referee ? `${ctx.referee}; tren historis kartu/gaya data tidak tersedia`: 'data tidak tersedia' },
    { name:'Cuaca / lapangan', weight:0.35, h:weatherSevere?0.97:1, a:weatherSevere?0.97:1, note:weather?.label || 'data tidak tersedia' },
    { name:'Psikologi', weight:0.35, h:1+psycheH, a:1+psycheA, note:(hs.form||as.form)?'inferensi dari tren hasil, bukan observasi psikologis langsung':'data tidak tersedia' },
    { name:'Kedalaman skuad', weight:0.35, h:squadHome!=null&&squadHome>0 ? 1 : 1, a:squadAway!=null&&squadAway>0 ? 1 : 1, note:squadHome!=null&&squadAway!=null?`Roster terdaftar ${squadHome} vs ${squadAway}`:'data tidak tersedia' },
  ];
}

function adjustLambdas(baseH, baseA, panel) {
  return {
    h: clamp(baseH * panel.h, 0.15, 4.5),
    a: clamp(baseA * panel.a, 0.15, 4.5)
  };
}

function eloLambdaAdjustment(homeElo, awayElo) {
  if (!Number.isFinite(homeElo) || !Number.isFinite(awayElo)) return {h:1,a:1};
  const diff = clamp((homeElo - awayElo) / 400, -1, 1);
  return { h: clamp(1 + diff*0.12, 0.90, 1.12), a: clamp(1 - diff*0.10, 0.90, 1.10) };
}

function run1200(ctx, baseH, baseA) {
  const panels = getPanelFactors(ctx);
  const seed = seedFromString(`${ctx.homeId}-${ctx.awayId}-${ctx.fixtureId || 'no-fixture'}`);
  const panelResults = [];
  let totals = new Map();
  let sumH=0,sumA=0,totalW=0;
  for (let pi=0; pi<panels.length; pi++) {
    const p = panels[pi];
    const {h:lh,a:la} = adjustLambdas(baseH, baseA, p);
    const rng = mulberry32(seed + pi*101);
    const dcDist = distribution(lh, la, -0.13, 8);
    const local = new Map();
    let ph=0,pa=0;
    for (let i=0;i<100;i++) {
      const sampled = sampleFromDistribution(dcDist,rng);
      const gh = sampled.h, ga = sampled.a;
      const key=`${gh}-${ga}`;
      local.set(key,(local.get(key)||0)+1);
      sumH += gh*p.weight; sumA += ga*p.weight; totalW += p.weight;
      const old = totals.get(key)||0; totals.set(key,old+p.weight);
      ph += gh*p.weight; pa += ga*p.weight;
    }
    const localDist = [...local.entries()].map(([k,c])=>{const [h,a]=k.split('-').map(Number);return {h,a,p:c/100};}).sort((a,b)=>b.p-a.p).slice(0,3);
    panelResults.push({ name:p.name, weight:p.weight, lambdaHome:+lh.toFixed(3), lambdaAway:+la.toFixed(3), top:localDist, note:p.note });
  }
  const dist = [...totals.entries()].map(([k,v])=>{const [h,a]=k.split('-').map(Number);return {h,a,p:v/(totalW*100)};});
  // Normalize weighted Monte Carlo distribution.
  const denom = dist.reduce((s,x)=>s+x.p,0);
  const normalized = dist.map(x=>({...x,p:x.p/denom}));
  const market = marketProbabilities(normalized);
  const votes={home:0,draw:0,away:0,total:panels.length};
  for(const p of panelResults){
    const top=p.top.reduce((s,x)=>s+x.p,0);
    const h=p.top.reduce((s,x)=>s+(x.h>x.a?x.p:0),0);
    const d=p.top.reduce((s,x)=>s+(x.h===x.a?x.p:0),0);
    const a=p.top.reduce((s,x)=>s+(x.h<x.a?x.p:0),0);
    const best=Math.max(h,d,a);
    if(best===h) votes.home++; else if(best===d) votes.draw++; else votes.away++;
  }
  const voteShare={home:votes.home/votes.total,draw:votes.draw/votes.total,away:votes.away/votes.total};
  const blended1x2={home:market.home*0.78+voteShare.home*0.22,draw:market.draw*0.78+voteShare.draw*0.22,away:market.away*0.78+voteShare.away*0.22};
  const z=blended1x2.home+blended1x2.draw+blended1x2.away;
  blended1x2.home/=z; blended1x2.draw/=z; blended1x2.away/=z;
  market.home=blended1x2.home; market.draw=blended1x2.draw; market.away=blended1x2.away;
  market.dc1X=market.home+market.draw; market.dc12=market.home+market.away; market.dcX2=market.draw+market.away;
  const avgH=sumH/totalW/100, avgA=sumA/totalW/100;
  return { panels:panelResults, dist:normalized, market, voteShare, meanHome:avgH, meanAway:avgA };
}

function confidenceLabel(model, ctx, dataQuality) {
  const certHome = model.market.home, certDraw=model.market.draw, certAway=model.market.away;
  const maxP = Math.max(certHome,certDraw,certAway);
  const spread = maxP - [...[certHome,certDraw,certAway]].sort((a,b)=>b-a)[1];
  const score = dataQuality*0.55 + clamp(spread*2.0,0,0.45);
  if (score >= 0.72) return 'Tinggi';
  if (score >= 0.48) return 'Menengah';
  return 'Rendah';
}

function inferReasons(ctx, model, oddsData) {
  const reasons=[];
  const hs=ctx.hs, as=ctx.as;
  if (hs.form) reasons.push(`Form ${ctx.homeName}: ${hs.form.slice(-5)}; ${as.form ? `${ctx.awayName}: ${as.form.slice(-5)}` : `${ctx.awayName}: data tidak tersedia`}`);
  const goalEdge=(hs.avgGF??null) != null && (as.avgGA??null)!=null ? (hs.avgGF-as.avgGA) : null;
  if (goalEdge!=null) reasons.push(`Rata-rata gol ${ctx.homeName} ${hs.avgGF.toFixed(2)} vs kebobolan tandang ${ctx.awayName} ${(as.awayGA??as.avgGA).toFixed(2)}`);
  else reasons.push('Statistik gol pembanding parsial; data yang tidak tersedia tidak diisi dengan angka buatan.');
  if (ctx.xgHome!=null || ctx.xgAway!=null) reasons.push(`xG: ${ctx.xgHome!=null?ctx.xgHome.toFixed(2):'data tidak tersedia'} vs ${ctx.xgAway!=null?ctx.xgAway.toFixed(2):'data tidak tersedia'}`);
  else if (ctx.standings?.length) reasons.push(`Klasemen tersedia; posisi ${ctx.homeName}: ${ctx.standings.find(x=>Number(x.team?.id)===Number(ctx.homeId))?.rank ?? 'data tidak tersedia'}, ${ctx.awayName}: ${ctx.standings.find(x=>Number(x.team?.id)===Number(ctx.awayId))?.rank ?? 'data tidak tersedia'}`);
  else reasons.push('H2H / klasemen tidak lengkap atau tidak tersedia untuk fixture ini.');
  return reasons.slice(0,3);
}

function riskText(ctx, model) {
  const missing=[];
  if (!ctx.xgHome && !ctx.xgAway) missing.push('xG');
  if (!ctx.referee) missing.push('wasit');
  if (!ctx.weather) missing.push('cuaca');
  if (!ctx.oddsRows?.length) missing.push('odds');
  if (!ctx.injuriesHome?.length && !ctx.injuriesAway?.length) missing.push('cedera/skorsing');
  const draw = model.market.draw;
  return missing.length ? `Risiko utama: ${missing.slice(0,2).join(' + ')} tidak tersedia${draw>0.3?', plus probabilitas seri cukup tinggi':''}.` : 'Risiko utama: ketidakpastian skor ekstrem dan perubahan lineup mendekati kick-off.';
}

function bestPick(ctx, model) {
  const candidates=[];
  const mp=model.market;
  const push=(market,label,p,odd,meta={})=>{
    const impliedP=odd ? implied(odd) : null;
    const ev=odd ? (p*odd - 1) : null;
    candidates.push({market,label,p,odd,impliedP,ev,...meta});
  };
  push('1X2',ctx.homeName,mp.home,ctx.markets.home?.odd);
  push('1X2','Draw',mp.draw,ctx.markets.draw?.odd);
  push('1X2',ctx.awayName,mp.away,ctx.markets.away?.odd);
  push('Double Chance','1X',mp.dc1X,ctx.markets.dc1X?.odd);
  push('Double Chance','12',mp.dc12,ctx.markets.dc12?.odd);
  push('Double Chance','X2',mp.dcX2,ctx.markets.dcX2?.odd);
  push('O/U','Over 2.5',mp.over25,ctx.markets.over25?.odd);
  push('O/U','Under 2.5',mp.under25,ctx.markets.under25?.odd);
  push('BTTS','Yes',mp.bttsYes,ctx.markets.bttsYes?.odd);
  push('BTTS','No',mp.bttsNo,ctx.markets.bttsNo?.odd);
  if (ctx.markets.ahHome?.odd) {
    const lineMatch=String(ctx.markets.ahHome.label).match(/(-?\d+(?:\.25|\.5|\.75|\.0)?)/);
    const line=lineMatch?parseFloat(lineMatch[1]):null;
    if (line!=null) { const ah=asianHandicapProb(model.dist,'home',line); push('Asian Handicap',`${ctx.homeName} ${line>=0?'+':''}${line}`,ah.effective,ctx.markets.ahHome.odd,{asian:ah,ev:evFromAsian(ctx.markets.ahHome.odd,ah)}); }
  }
  if (ctx.markets.ahAway?.odd) {
    const lineMatch=String(ctx.markets.ahAway.label).match(/(-?\d+(?:\.25|\.5|\.75|\.0)?)/);
    const line=lineMatch?parseFloat(lineMatch[1]):null;
    if (line!=null) { const ah=asianHandicapProb(model.dist,'away',line); push('Asian Handicap',`${ctx.awayName} ${line>=0?'+':''}${line}`,ah.effective,ctx.markets.ahAway.odd,{asian:ah,ev:evFromAsian(ctx.markets.ahAway.odd,ah)}); }
  }
  // Prefer positive value bets; otherwise highest model probability.
  const withOdds=candidates.filter(c=>c.odd && c.odd>1.01 && Number.isFinite(c.ev));
  const positive=withOdds.filter(c=>c.ev>0.01).sort((a,b)=>b.ev-a.ev);
  return (positive[0] || withOdds.sort((a,b)=>b.p-a.p)[0] || candidates.sort((a,b)=>b.p-a.p)[0]);
}

async function searchTeam(name) {
  return cached(`team-search:${norm(name)}`, async ()=>{
    const data=await apiFootball('/teams',{search:name});
    const rows=data.response||[];
    rows.sort((a,b)=>{
      const an=norm(a.team?.name), bn=norm(b.team?.name), q=norm(name);
      const score=(n)=>n===q?0:n.startsWith(q)?1:n.includes(q)?2:3;
      return score(an)-score(bn);
    });
    return rows.slice(0,8).map(x=>({id:x.team?.id,name:x.team?.name,logo:x.team?.logo,venue:x.venue||null,country:x.team?.country||null}));
  }, 24*60*60*1000);
}

async function getRecent(teamId) {
  return cached(`fixtures:last:${teamId}`, async ()=> (await apiFootball('/fixtures',{team:teamId,last:10})).response||[], 30*60*1000);
}
async function getUpcoming(teamId) {
  return cached(`fixtures:next:${teamId}`, async ()=> (await apiFootball('/fixtures',{team:teamId,next:50})).response||[], 10*60*1000);
}
async function findFixture(homeId, awayId) {
  const fromHome=await getUpcoming(homeId);
  let found=fromHome.find(f=>Number(f.teams?.away?.id)===Number(awayId) && !statusPlayed(f));
  if (found) return found;
  const fromAway=await getUpcoming(awayId);
  found=fromAway.find(f=>Number(f.teams?.home?.id)===Number(homeId) && !statusPlayed(f));
  return found || null;
}

async function getStandingsForFixture(fixture, homeId, awayId) {
  if (!fixture?.league?.id || !fixture?.league?.season) return [];
  const data=await cached(`standings:${fixture.league.id}:${fixture.league.season}`, async ()=>await apiFootball('/standings',{league:fixture.league.id,season:fixture.league.season}), 60*60*1000);
  const all=[];
  for (const r of data.response||[]) {
    for (const group of r.league?.standings||[]) all.push(...group);
  }
  return all;
}

async function getTeamStats(teamId, fixture) {
  if (!fixture?.league?.id || !fixture?.league?.season) return null;
  const data=await cached(`teamstats:${teamId}:${fixture.league.id}:${fixture.league.season}`, async ()=>await apiFootball('/teams/statistics',{league:fixture.league.id,season:fixture.league.season,team:teamId}), 2*60*60*1000);
  return data.response||null;
}
async function getInjuries(teamId, season, fixtureId=null) {
  if (!season) return [];
  const key = fixtureId ? `injuries:fixture:${fixtureId}:${teamId}` : `injuries:${teamId}:${season}`;
  const params = fixtureId ? {fixture:fixtureId, team:teamId} : {team:teamId,season};
  try {
    const data=await cached(key, async ()=>await apiFootball('/injuries',params), 4*60*60*1000);
    return data.response||[];
  } catch { return []; }
}
async function getSquadCount(teamId) {
  try {
    const data=await cached(`squad:${teamId}`, async ()=>await apiFootball('/players/squads',{team:teamId}), 6*60*60*1000);
    const response=data.response||[];
    if (!response.length) return null;
    const players=response.flatMap(x=>x.players||[]);
    return players.length || null;
  } catch { return null; }
}

async function getWeather(fixture) {
  const city=fixture?.venue?.city;
  const date=fixture?.date;
  if (!city || !date) return null;
  try {
    const ge=await cached(`geo:${norm(city)}`, async ()=>await weatherGet(`${GEOCODE_BASE}?name=${encodeURIComponent(city)}&count=1&language=en&format=json`), 24*60*60*1000);
    const loc=ge?.results?.[0];
    if (!loc) return null;
    const wx=await weatherGet(`${WEATHER_BASE}?latitude=${loc.latitude}&longitude=${loc.longitude}&hourly=temperature_2m,precipitation,precipitation_probability,wind_speed_10m&forecast_days=16&timezone=auto`);
    const target=new Date(date);
    const times=wx?.hourly?.time||[];
    let idx=-1, best=Infinity;
    for (let i=0;i<times.length;i++) {
      const d=Math.abs(new Date(times[i]).getTime()-target.getTime());
      if (d<best) {best=d;idx=i;}
    }
    if (idx<0) return null;
    const temp=wx.hourly.temperature_2m?.[idx];
    const precip=wx.hourly.precipitation?.[idx];
    const prob=wx.hourly.precipitation_probability?.[idx];
    const wind=wx.hourly.wind_speed_10m?.[idx];
    return {
      city: loc.name,
      timezone: wx.timezone,
      time: times[idx],
      tempC:Number.isFinite(temp)?temp:null,
      precipMm:Number.isFinite(precip)?precip:null,
      rainProb:Number.isFinite(prob)?prob:null,
      windKmh:Number.isFinite(wind)?wind:null,
      label:[Number.isFinite(temp)?`${temp.toFixed(1)}°C`:null,Number.isFinite(prob)?`hujan ${prob}%`:null,Number.isFinite(wind)?`angin ${wind.toFixed(0)} km/j`:null].filter(Boolean).join(' • ') || 'data tidak tersedia'
    };
  } catch { return null; }
}

function countLast14(fixtures) {
  const since=Date.now()-14*86400000;
  return (fixtures||[]).filter(statusPlayed).filter(f=>new Date(f.fixture.date).getTime()>=since).length;
}

function oddsFromUser(userOdds) {
  if (!Array.isArray(userOdds)) return [];
  return userOdds.filter(x=>x && Number.isFinite(Number(x.odd))).map(x=>({
    bookmaker:x.bookmaker||'OCR',betName:x.betName||x.market||'OCR',label:x.label||x.selection||'',odd:Number(x.odd)
  }));
}

async function analyzeMatch(input) {
  const homeId=Number(input.homeId), awayId=Number(input.awayId);
  const homeName=input.homeName, awayName=input.awayName;
  const [homeRecent, awayRecent, fixture] = await Promise.all([
    getRecent(homeId), getRecent(awayId), findFixture(homeId,awayId)
  ]);
  const fx=fixture;
  const season=fx?.league?.season || new Date().getUTCFullYear();
  const [h2hData, standings, injuriesHome, injuriesAway, hTeamStats, aTeamStats, weather, squadHome, squadAway] = await Promise.all([
    cached(`h2h:${homeId}:${awayId}`, async ()=> (await apiFootball('/fixtures/headtohead',{h2h:`${homeId}-${awayId}`,last:10})).response||[], 12*60*60*1000).catch(()=>[]),
    getStandingsForFixture(fx,homeId,awayId).catch(()=>[]),
    getInjuries(homeId,season,fx?.fixture?.id).catch(()=>[]),
    getInjuries(awayId,season,fx?.fixture?.id).catch(()=>[]),
    getTeamStats(homeId,fx).catch(()=>null),
    getTeamStats(awayId,fx).catch(()=>null),
    getWeather(fx).catch(()=>null),
    getSquadCount(homeId),
    getSquadCount(awayId),
  ]);
  let oddsRaw=null, oddsRows=[], externalPrediction=null;
  if (fx?.fixture?.id) {
    try {
      const pred=await cached(`prediction:${fx.fixture.id}`, async()=>await apiFootball('/predictions',{fixture:fx.fixture.id}), 60*60*1000);
      externalPrediction=pred?.response?.[0] || null;
    } catch {}
  }
  if (fx?.fixture?.id) {
    try {
      oddsRaw=await cached(`odds:${fx.fixture.id}`, async ()=>await apiFootball('/odds',{fixture:fx.fixture.id}), 3*60*60*1000);
      oddsRows=flattenOdds(oddsRaw).rows;
    } catch {}
  }
  const userRows=oddsFromUser(input.odds);
  const finalOdds=userRows.length ? userRows : oddsRows;
  const hs=summarizeFixtures(homeRecent,homeId), as=summarizeFixtures(awayRecent,awayId);

  // Try to find xG in any fixture-statistics response without inventing it.
  let xgHome=null,xgAway=null;
  const xgCandidates=[homeRecent?.at(-1), awayRecent?.at(-1)].filter(Boolean);
  for (const f of xgCandidates) {
    try {
      const st=await cached(`fxstats:${f.fixture.id}`, async ()=>await apiFootball('/fixtures/statistics',{fixture:f.fixture.id}), 6*60*60*1000);
      const xidH=extractXg(st,homeId), xidA=extractXg(st,awayId);
      if (xidH!=null && xgHome==null) xgHome=xidH;
      if (xidA!=null && xgAway==null) xgAway=xidA;
    } catch {}
    if (xgHome!=null && xgAway!=null) break;
  }
  const markets=normalizeMarketRows(finalOdds,homeName,awayName);

  // Shrink recent goal means toward a transparent neutral prior when samples are thin.
  const prior=1.35;
  const shrink=(v,n)=> v==null ? prior : (v*n + prior*3)/(n+3);
  const eloHome=calcElo(homeRecent,homeId,standings);
  const eloAway=calcElo(awayRecent,awayId,standings);
  const eloAdj=eloLambdaAdjustment(eloHome,eloAway);
  const baseH=clamp((((shrink(hs.homeGF??hs.weightedGF,hs.homeN||hs.recentN)) + (shrink(as.awayGA??as.weightedGA,as.awayN||as.recentN)))/2)*eloAdj.h,0.15,3.8);
  const baseA=clamp((((shrink(as.awayGF??as.weightedGF,as.awayN||as.recentN)) + (shrink(hs.homeGA??hs.weightedGA,hs.homeN||hs.recentN)))/2)*eloAdj.a,0.15,3.8);
  const referee=fx?.fixture?.referee || null;
  const ctx={
    homeId,awayId,fixtureId:fx?.fixture?.id||null,homeName,awayName,
    hs,as,h2h:h2hData,standings,inuriesHome:injuriesHome,inuriesAway:injuriesAway,
    injuriesHome,injuriesAway,xgHome,xgAway,weather,referee,
    recent14H:countLast14(homeRecent), recent14A:countLast14(awayRecent),
    squadHome,squadAway, oddsRows:finalOdds, markets, eloHome, eloAway
  };
  const simulation=run1200(ctx,baseH,baseA);
  const modelDist=simulation.dist;
  const best=bestPick(ctx,simulation);
  const dataQuality=clamp([
    hs.recentN>=8?1:hs.recentN/8,
    as.recentN>=8?1:as.recentN/8,
    h2hData?.length?1:0.4,
    standings?.length?1:0.5,
    fx?1:0.35,
    injuriesHome?.length||injuriesAway?.length?1:0.5,
    xgHome!=null||xgAway!=null?1:0.4,
    finalOdds.length?1:0.5
  ].reduce((a,b)=>a+b,0)/8,0,1);
  const confidence=confidenceLabel(simulation,ctx,dataQuality);
  const reasons=inferReasons(ctx,simulation,finalOdds);
  const risk=riskText(ctx,simulation);
  const oneLiner=`${homeName} vs ${awayName}, ${best.label} @${best.odd?best.odd.toFixed(2):'odds tidak tersedia'}: ${fmtPct(best.p)} • Keyakinan ${confidence}`;

  return {
    input:{homeName,awayName,homeId,awayId}, fixture:fx ? {
      id:fx.fixture.id,date:fx.fixture.date,timezone:fx.fixture.timezone,venue:fx.fixture.venue,league:fx.league,referee
    } : null,
    oneLiner, confidence, reasons, risk,
    model:{baseHome:+baseH.toFixed(3),baseAway:+baseA.toFixed(3),meanHome:+simulation.meanHome.toFixed(3),meanAway:+simulation.meanAway.toFixed(3),elo:{home:+eloHome.toFixed(0),away:+eloAway.toFixed(0),type:'proxy Elo lokal'},markets:simulation.market,correctScores:simulation.market.correct,panelResults:simulation.panels,voteShare:simulation.voteShare},
    odds:{source:userRows.length?'OCR / input user':'API-Football', rows:finalOdds.slice(0,120), normalized:markets},
    valueBet:best ? {market:best.market,label:best.label,modelProbability:best.p,odd:best.odd||null,impliedProbability:best.impliedP||null,ev:best.ev||null,asian:best.asian||null} : null,
    data:{
      recentHome:hs.rows.slice(-10),recentAway:as.rows.slice(-10),
      h2h:(h2hData||[]).slice(-10).map(f=>({date:f.fixture.date,home:f.teams?.home?.name,away:f.teams?.away?.name,homeGoals:f.goals?.home,awayGoals:f.goals?.away,league:f.league?.name})),
      standings:(standings||[]).filter(x=>[homeId,awayId].includes(Number(x.team?.id))).map(x=>({rank:x.rank,team:x.team?.name,points:x.points,form:x.form,goalsDiff:x.goalsDiff,home:x.home,away:x.away})),
      injuriesHome:injuriesHome.slice(0,30).map(x=>({player:x.player?.name,reason:x.player?.reason,type:x.type,date:x.fixture?.date})),
      injuriesAway:injuriesAway.slice(0,30).map(x=>({player:x.player?.name,reason:x.player?.reason,type:x.type,date:x.fixture?.date})),
      xG:{home:xgHome,away:xgAway},
      teamStats:{home:hTeamStats,away:aTeamStats},
      weather,
      squadDepth:{home:squadHome,away:squadAway},
      externalPrediction: externalPrediction ? {winner:externalPrediction.predictions?.winner,advice:externalPrediction.predictions?.advice,underOver:externalPrediction.predictions?.under_over,percent:externalPrediction.predictions?.percent,goals:externalPrediction.predictions?.goals} : null
    },
    meta:{dataQuality:+dataQuality.toFixed(2),simulationUnits:12*100,warning:'Probabilitas adalah keluaran model, bukan jaminan hasil atau profit.'}
  };
}

async function handleApi(req,res,url) {
  if (!rateAllowed(req)) return json(res,429,{error:'Terlalu banyak request. Coba lagi sebentar.'});
  if (url.pathname==='/api/health') {
    return json(res,200,{ok:true,apiKeyConfigured:Boolean(API_KEY),time:new Date().toISOString(),cacheItems:cache.size});
  }
  if (url.pathname==='/api/live') {
    if (!API_KEY) return json(res,503,{error:'API_FOOTBALL_KEY belum diisi di environment server.'});
    try {
      const live=await cached('live:all', async()=>await apiFootball('/fixtures',{live:'all'}), 15_000);
      const rows=(live?.response||[]).map(f=>({
        id:f.fixture?.id,
        status:f.fixture?.status?.short || null,
        elapsed:f.fixture?.status?.elapsed ?? null,
        extra:f.fixture?.status?.extra ?? null,
        date:f.fixture?.date || null,
        league:{id:f.league?.id,name:f.league?.name,country:f.league?.country,logo:f.league?.logo},
        home:{id:f.teams?.home?.id,name:f.teams?.home?.name,logo:f.teams?.home?.logo,winner:f.teams?.home?.winner ?? null},
        away:{id:f.teams?.away?.id,name:f.teams?.away?.name,logo:f.teams?.away?.logo,winner:f.teams?.away?.winner ?? null},
        score:{home:f.goals?.home ?? null,away:f.goals?.away ?? null,halftime:f.score?.halftime ?? null},
        venue:f.fixture?.venue || null
      }));
      return json(res,200,{updatedAt:new Date().toISOString(),count:rows.length,matches:rows,source:'API-Football'});
    } catch(e){ return json(res,502,{error:e.message}); }
  }
  if (url.pathname==='/api/live-match') {
    if (!API_KEY) return json(res,503,{error:'API_FOOTBALL_KEY belum diisi di environment server.'});
    const id=Number(url.searchParams.get('fixture'));
    if (!Number.isFinite(id)) return json(res,400,{error:'fixture tidak valid'});
    try {
      const data=await cached(`live-match:${id}`, async()=>await apiFootball('/fixtures',{id}), 15_000);
      return json(res,200,{updatedAt:new Date().toISOString(),fixture:data?.response?.[0]||null,source:'API-Football'});
    } catch(e){ return json(res,502,{error:e.message}); }
  }
  if (url.pathname==='/api/team-search') {
    const name=url.searchParams.get('name')||'';
    if (norm(name).length<3) return json(res,400,{error:'Masukkan minimal 3 karakter.'});
    try { return json(res,200,{results:await searchTeam(name)}); }
    catch(e){ return json(res,502,{error:e.message}); }
  }
  if (url.pathname==='/api/analyze') {
    if (!API_KEY) return json(res,503,{error:'API_FOOTBALL_KEY belum diisi di environment server.'});
    try {
      const raw=await new Promise((resolve,reject)=>{
        let body=''; req.on('data',c=>{body+=c; if(body.length>MAX_BODY_BYTES) reject(new Error('payload terlalu besar'));}); req.on('end',()=>{try{resolve(JSON.parse(body||'{}'));}catch(e){reject(new Error('JSON tidak valid'));}}); req.on('error',reject);
      });
      const out=await analyzeMatch(raw);
      return json(res,200,out);
    } catch(e) {
      return json(res,500,{error:e.message || 'Gagal menganalisis laga.'});
    }
  }
  return json(res,404,{error:'route tidak ditemukan'});
}

const server=http.createServer(async (req,res)=>{
  try {
    if (req.method==='OPTIONS') { res.writeHead(204,{'Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'Content-Type','Access-Control-Allow-Methods':'GET,POST,OPTIONS'}); return res.end(); }
    const url=new URL(req.url,`http://${req.headers.host}`);
    if (url.pathname.startsWith('/api/')) return handleApi(req,res,url);
    let file=url.pathname==='/'?'index.html':url.pathname.slice(1);
    if (file.includes('..')) return json(res,400,{error:'invalid path'});
    const full=path.join(PUBLIC_DIR,file);
    return sendFile(res,full);
  } catch(e) { return json(res,500,{error:e.message}); }
});

server.listen(PORT,()=>console.log(`Super Analis Bola berjalan di http://localhost:${PORT}`));
