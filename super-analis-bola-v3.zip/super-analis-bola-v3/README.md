# Super Analis Bola LIVE — v3

Versi ini mempertahankan mesin analisis profesional dan menambahkan pengalaman aplikasi skor sepak bola bergaya SofaScore: daftar pertandingan live, menit/skor, detail event, dan tombol **Super Analisis**.

## Data & live mode

Backend menggunakan API-Football sebagai provider data. Endpoint live mengambil `fixtures?live=all`; data detail pertandingan dapat mencakup events, lineups, statistics dan players. API-Football menyatakan data fixtures/events live diperbarui sekitar setiap 15 detik. Aplikasi menyediakan refresh 15/30/60 detik atau manual untuk mengendalikan kuota. Sumber: API-Football.

## Jalankan

1. `npm install`
2. Salin `.env.example` menjadi `.env`
3. Isi `API_FOOTBALL_KEY=...`
4. `npm start`
5. Buka `http://localhost:3000`

Jangan masukkan API key ke file frontend atau repository publik. Gunakan environment variable server.

## Struktur

- `server.js` — backend, cache, rate limit, data live, analisis
- `public/index.html` — UI aplikasi
- `public/app.js` — live dashboard + alur analisis
- `public/styles.css` — desain mobile-first dark premium

## Prinsip data

Aplikasi tidak membuat skor live, statistik, cedera, odds, atau data lain yang tidak diterima dari provider. Untuk field yang tidak tersedia, tampilkan `data tidak tersedia`.

Prediksi adalah probabilitas model, bukan jaminan hasil pertandingan atau profit.
